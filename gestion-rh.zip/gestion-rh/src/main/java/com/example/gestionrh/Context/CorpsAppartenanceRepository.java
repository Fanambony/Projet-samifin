package com.example.gestionrh.Context;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.gestionrh.Model.Entity.CorpsAppartenance;

public interface CorpsAppartenanceRepository extends JpaRepository<CorpsAppartenance, Object> {

}