package com.example.gestionrh.Context;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.gestionrh.Model.Entity.DemandeConge;

public interface DemandeCongeRepository extends JpaRepository<DemandeConge, Object> {
    
}