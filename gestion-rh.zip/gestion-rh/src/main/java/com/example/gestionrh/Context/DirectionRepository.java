package com.example.gestionrh.Context;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.gestionrh.Model.Entity.Direction;

public interface DirectionRepository extends JpaRepository<Direction, Object> {

}