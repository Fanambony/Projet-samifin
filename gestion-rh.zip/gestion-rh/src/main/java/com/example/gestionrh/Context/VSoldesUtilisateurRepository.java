package com.example.gestionrh.Context;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.gestionrh.Model.Entity.VSoldesUtilisateur;

public interface VSoldesUtilisateurRepository extends JpaRepository<VSoldesUtilisateur, Object> {

}