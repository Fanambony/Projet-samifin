package com.example.gestionrh.Context;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.gestionrh.Model.Entity.InterimUtilisateur;

public interface InterimUtilisateurRepository extends JpaRepository<InterimUtilisateur, Object> {
    
}